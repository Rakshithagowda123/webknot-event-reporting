-- Reports for Campus Event Reporting

-- 1) Total registrations per event (optionally filter by college_id)
-- SELECT e.id, e.title, e.type, e.start_datetime, COUNT(r.id) as registrations
-- FROM events e
-- LEFT JOIN registrations r ON r.event_id = e.id
-- WHERE e.college_id = :college_id -- optional
-- GROUP BY e.id
-- ORDER BY registrations DESC;

-- 2) Attendance percentage for an event
-- SELECT e.id as event_id, e.title,
--        COUNT(r.id) as total_registered,
--        SUM(CASE WHEN a.present = 1 THEN 1 ELSE 0 END) as total_present,
--        ROUND(100.0 * SUM(CASE WHEN a.present = 1 THEN 1 ELSE 0 END) / NULLIF(COUNT(r.id), 0), 2) as attendance_percentage
-- FROM events e
-- LEFT JOIN registrations r ON r.event_id = e.id
-- LEFT JOIN attendance a ON a.event_id = e.id AND a.student_id = r.student_id
-- WHERE e.id = :event_id
-- GROUP BY e.id;

-- 3) Average feedback score for an event
-- SELECT e.id, e.title, ROUND(AVG(f.rating), 2) as avg_rating, COUNT(f.id) as ratings_count
-- FROM events e
-- LEFT JOIN feedback f ON f.event_id = e.id
-- WHERE e.id = :event_id
-- GROUP BY e.id;

-- 4) Student participation report (how many events a student attended)
-- SELECT s.id as student_id, s.name, COUNT(a.id) as attended_count
-- FROM students s
-- LEFT JOIN attendance a ON a.student_id = s.id AND a.present = 1
-- WHERE s.id = :student_id
-- GROUP BY s.id;

-- 5) Top N most active students in a college (by number of events attended)
-- SELECT s.id, s.name, COUNT(a.id) as attended_count
-- FROM students s
-- JOIN attendance a ON a.student_id = s.id AND a.present = 1
-- WHERE s.college_id = :college_id
-- GROUP BY s.id
-- ORDER BY attended_count DESC
-- LIMIT :limit;

-- 6) Event popularity filtered by type
-- SELECT e.id, e.title, e.type, COUNT(r.id) as registrations
-- FROM events e
-- LEFT JOIN registrations r ON r.event_id = e.id
-- WHERE e.college_id = :college_id AND e.type = :type
-- GROUP BY e.id
-- ORDER BY registrations DESC;