import os
from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func, case
from models import db, College, Student, Event, Registration, Attendance, Feedback

def create_app():
    app = Flask(__name__)
    db_url = os.getenv('DATABASE_URL', 'sqlite:///campus.db')
    app.config['SQLALCHEMY_DATABASE_URI'] = db_url
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    db.init_app(app)

    @app.get('/')
    def root():
        return jsonify({'message': 'Campus Event Reporting API is running'})

    # ---------- Admin endpoints ----------
    @app.post('/colleges')
    def create_college():
        data = request.get_json(force=True)
        c = College(name=data['name'], code=data.get('code'))
        db.session.add(c)
        db.session.commit()
        return jsonify({'id': c.id, 'name': c.name, 'code': c.code}), 201

    @app.post('/students')
    def create_student():
        data = request.get_json(force=True)
        s = Student(
            college_id=data['college_id'],
            name=data['name'],
            email=data['email'],
            year=data.get('year'),
            branch=data.get('branch')
        )
        db.session.add(s)
        db.session.commit()
        return jsonify({'id': s.id, 'name': s.name, 'email': s.email}), 201

    @app.post('/events')
    def create_event():
        data = request.get_json(force=True)
        e = Event(
            college_id=data['college_id'],
            title=data['title'],
            type=data['type'],
            description=data.get('description'),
            location=data.get('location'),
            start_datetime=data['start_datetime'],
            end_datetime=data['end_datetime']
        )
        db.session.add(e)
        db.session.commit()
        return jsonify({'id': e.id, 'title': e.title, 'type': e.type}), 201

    # ---------- Student actions ----------
    @app.post('/register')
    def register_student():
        data = request.get_json(force=True)
        r = Registration(student_id=data['student_id'], event_id=data['event_id'])
        db.session.add(r)
        db.session.commit()
        return jsonify({'id': r.id, 'student_id': r.student_id, 'event_id': r.event_id}), 201

    @app.post('/attendance')
    def mark_attendance():
        data = request.get_json(force=True)
        a = Attendance(student_id=data['student_id'], event_id=data['event_id'], present=int(bool(data.get('present', True))))
        db.session.add(a)
        db.session.commit()
        return jsonify({'id': a.id, 'present': a.present}), 201

    @app.post('/feedback')
    def submit_feedback():
        data = request.get_json(force=True)
        rating = int(data['rating'])
        if rating < 1 or rating > 5:
            return jsonify({'error': 'rating must be 1-5'}), 400
        f = Feedback(student_id=data['student_id'], event_id=data['event_id'], rating=rating, comment=data.get('comment'))
        db.session.add(f)
        db.session.commit()
        return jsonify({'id': f.id, 'rating': f.rating}), 201

    # ---------- Reports ----------
    @app.get('/reports/event_popularity')
    def event_popularity():
        college_id = request.args.get('college_id', type=int)
        type_filter = request.args.get('type')
        q = db.session.query(
            Event.id,
            Event.title,
            Event.type,
            func.count(Registration.id).label('registrations')
        ).outerjoin(Registration, Registration.event_id == Event.id)
        if college_id:
            q = q.filter(Event.college_id == college_id)
        if type_filter:
            q = q.filter(Event.type == type_filter)
        q = q.group_by(Event.id).order_by(func.count(Registration.id).desc())
        return jsonify([{'event_id': r.id, 'title': r.title, 'type': r.type, 'registrations': r.registrations} for r in q.all()])

    @app.get('/reports/event_attendance/<int:event_id>')
    def event_attendance(event_id):
        total_registered = db.session.query(func.count(Registration.id)).filter(Registration.event_id == event_id).scalar()
        total_present = db.session.query(func.count(Attendance.id)).filter(Attendance.event_id == event_id, Attendance.present == 1).scalar()
        percentage = round(100.0 * total_present / total_registered, 2) if total_registered else 0.0
        e = Event.query.get_or_404(event_id)
        return jsonify({'event_id': event_id, 'title': e.title, 'total_registered': total_registered, 'total_present': total_present, 'attendance_percentage': percentage})

    @app.get('/reports/event_feedback/<int:event_id>')
    def event_feedback(event_id):
        avg_rating, count = db.session.query(func.avg(Feedback.rating), func.count(Feedback.id)).filter(Feedback.event_id == event_id).one()
        avg = round(float(avg_rating), 2) if avg_rating is not None else None
        e = Event.query.get_or_404(event_id)
        return jsonify({'event_id': event_id, 'title': e.title, 'avg_rating': avg, 'ratings_count': count})

    @app.get('/reports/student_participation/<int:student_id>')
    def student_participation(student_id):
        attended = db.session.query(func.count(Attendance.id)).filter(Attendance.student_id == student_id, Attendance.present == 1).scalar()
        return jsonify({'student_id': student_id, 'attended_count': attended})

    @app.get('/reports/top_active_students')
    def top_active_students():
        college_id = request.args.get('college_id', type=int)
        limit = request.args.get('limit', default=3, type=int)
        q = db.session.query(
            Student.id,
            Student.name,
            func.count(Attendance.id).label('attended_count')
        ).join(Attendance, Attendance.student_id == Student.id).filter(Attendance.present == 1)
        if college_id:
            q = q.filter(Student.college_id == college_id)
        q = q.group_by(Student.id).order_by(func.count(Attendance.id).desc()).limit(limit)
        return jsonify([{'student_id': r.id, 'name': r.name, 'attended_count': r.attended_count} for r in q.all()])

    return app

app = create_app()

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)