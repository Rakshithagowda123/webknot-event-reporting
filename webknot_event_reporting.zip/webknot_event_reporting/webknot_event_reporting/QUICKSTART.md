# Quickstart

python -m venv .venv
# On Windows PowerShell:
.venv\Scripts\Activate.ps1
# On macOS/Linux:
# source .venv/bin/activate

pip install -r requirements.txt

# Seed database with sample data
python db_init.py

# Run the API
flask --app app run

# Example cURL usage:

# Create college
curl -X POST http://127.0.0.1:5000/colleges -H "Content-Type: application/json" -d "{\"name\": \"ACME College\", \"code\": \"ACME\"}"

# Create student
curl -X POST http://127.0.0.1:5000/students -H "Content-Type: application/json" -d "{\"college_id\": 1, \"name\": \"Alice\", \"email\": \"alice@acme.edu\"}"

# Create event
curl -X POST http://127.0.0.1:5000/events -H "Content-Type: application/json" -d "{\"college_id\": 1, \"title\": \"ML Workshop\", \"type\": \"Workshop\", \"start_datetime\": \"2025-09-10T10:00:00\", \"end_datetime\": \"2025-09-10T13:00:00\", \"location\": \"Auditorium\"}"

# Register student to event
curl -X POST http://127.0.0.1:5000/register -H "Content-Type: application/json" -d "{\"student_id\": 1, \"event_id\": 1}"

# Mark attendance
curl -X POST http://127.0.0.1:5000/attendance -H "Content-Type: application/json" -d "{\"student_id\": 1, \"event_id\": 1, \"present\": true}"

# Submit feedback
curl -X POST http://127.0.0.1:5000/feedback -H "Content-Type: application/json" -d "{\"student_id\": 1, \"event_id\": 1, \"rating\": 5, \"comment\": \"Loved it!\"}"

# Reports
curl http://127.0.0.1:5000/reports/event_popularity?college_id=1
curl http://127.0.0.1:5000/reports/event_attendance/1
curl http://127.0.0.1:5000/reports/event_feedback/1
curl http://127.0.0.1:5000/reports/student_participation/1
curl "http://127.0.0.1:5000/reports/top_active_students?college_id=1&limit=3"