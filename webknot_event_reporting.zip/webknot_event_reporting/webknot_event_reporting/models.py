from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class College(db.Model):
    __tablename__ = 'colleges'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String, nullable=False)
    code = db.Column(db.String, unique=True)

    students = db.relationship('Student', backref='college', cascade='all, delete-orphan')
    events = db.relationship('Event', backref='college', cascade='all, delete-orphan')

class Student(db.Model):
    __tablename__ = 'students'
    id = db.Column(db.Integer, primary_key=True)
    college_id = db.Column(db.Integer, db.ForeignKey('colleges.id'), nullable=False)
    name = db.Column(db.String, nullable=False)
    email = db.Column(db.String, nullable=False)
    year = db.Column(db.Integer)
    branch = db.Column(db.String)

    __table_args__ = (db.UniqueConstraint('college_id', 'email', name='uq_student_email_per_college'), )

class Event(db.Model):
    __tablename__ = 'events'
    id = db.Column(db.Integer, primary_key=True)
    college_id = db.Column(db.Integer, db.ForeignKey('colleges.id'), nullable=False)
    title = db.Column(db.String, nullable=False)
    type = db.Column(db.String, nullable=False)  # Workshop/Hackathon/Seminar/Fest/TechTalk
    description = db.Column(db.Text)
    location = db.Column(db.String)
    start_datetime = db.Column(db.String, nullable=False)  # ISO string for simplicity
    end_datetime = db.Column(db.String, nullable=False)

    __table_args__ = (db.UniqueConstraint('college_id', 'title', 'start_datetime', name='uq_event_title_time_per_college'), )

class Registration(db.Model):
    __tablename__ = 'registrations'
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('students.id'), nullable=False)
    event_id = db.Column(db.Integer, db.ForeignKey('events.id'), nullable=False)
    registered_at = db.Column(db.String, default=lambda: datetime.utcnow().isoformat())

    __table_args__ = (db.UniqueConstraint('student_id', 'event_id', name='uq_registration_unique'), )

class Attendance(db.Model):
    __tablename__ = 'attendance'
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('students.id'), nullable=False)
    event_id = db.Column(db.Integer, db.ForeignKey('events.id'), nullable=False)
    present = db.Column(db.Integer, nullable=False)  # 0/1
    marked_at = db.Column(db.String, default=lambda: datetime.utcnow().isoformat())

    __table_args__ = (db.UniqueConstraint('student_id', 'event_id', name='uq_attendance_unique'), )

class Feedback(db.Model):
    __tablename__ = 'feedback'
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('students.id'), nullable=False)
    event_id = db.Column(db.Integer, db.ForeignKey('events.id'), nullable=False)
    rating = db.Column(db.Integer, nullable=False)  # 1-5
    comment = db.Column(db.Text)
    created_at = db.Column(db.String, default=lambda: datetime.utcnow().isoformat())

    __table_args__ = (db.UniqueConstraint('student_id', 'event_id', name='uq_feedback_unique'), )