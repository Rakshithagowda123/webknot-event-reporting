# Admin Portal – Simple Wireframe (Text Sketch)

- Dashboard
  - Create Event [Title, Type, Dates, Location, Description]
  - List of Events (with registrations count)

- Event View
  - Registrations Table
  - Mark Attendance [Mark Present]
  - Feedback Summary (Average Rating, Comments)

- Reports
  - Event Popularity (sortable, filter by type)
  - Student Participation per student
  - Top 3 Most Active Students