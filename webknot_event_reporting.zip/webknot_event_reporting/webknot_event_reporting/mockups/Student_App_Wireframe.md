# Student App – Simple Wireframe (Text Sketch)

- Home
  - Search/Filter by Type [Workshop | Hackathon | Seminar | Fest | TechTalk]
  - Event Cards: Title • Date • Location • [Register]

- Event Detail
  - Title, Type, Date/Time, Location, Description
  - [Register] / [Cancel Registration]
  - [Check-in] (QR-based | future)
  - [Give Feedback 1–5] (post-event)

- Profile
  - Name, Email
  - Participation Stats (Events Attended, Avg Rating Given)