# Design Document – Campus Event Reporting

## Scope
Track **event creation**, **student registration**, **attendance**, and **feedback** for a multi-college setup.

## Data to Track
- Colleges
- Students
- Events (type: Workshop/Hackathon/Seminar/Fest/TechTalk)
- Registrations (student ↔ event)
- Attendance (present/absent)
- Feedback (1–5 rating + optional comment)

## Multi-Tenancy Assumption
- Single database shared by all colleges.
- Each row includes `college_id` where applicable (students, events).
- Event IDs are unique per database, *but* business uniqueness is enforced as `(college_id, title, start_datetime)` to allow same titles across colleges.

## Database Schema (tables)
**colleges**(id, name, code[unique])  
**students**(id, college_id, name, email, year, branch, UNIQUE(college_id,email))  
**events**(id, college_id, title, type, description, location, start_datetime, end_datetime, UNIQUE(college_id,title,start_datetime))  
**registrations**(id, student_id, event_id, registered_at, UNIQUE(student_id,event_id))  
**attendance**(id, student_id, event_id, present[0/1], marked_at, UNIQUE(student_id,event_id))  
**feedback**(id, student_id, event_id, rating[1–5], comment, created_at, UNIQUE(student_id,event_id))

> Duplicate control is via UNIQUE constraints. Attendance & Feedback are one-per-student-per-event.

## ER Sketch (Mermaid)
```mermaid
erDiagram
    colleges ||--o{ students : has
    colleges ||--o{ events : hosts
    students ||--o{ registrations : registers
    events ||--o{ registrations : receives
    students ||--o{ attendance : checks
    events ||--o{ attendance : records
    students ||--o{ feedback : gives
    events ||--o{ feedback : receives
```

## API Design
- POST `/colleges` → create a college
- POST `/students` → create student
- POST `/events` → create event
- POST `/register` → register student to event
- POST `/attendance` → mark attendance `{present: true|false}`
- POST `/feedback` → submit feedback `rating:1..5`
- GET `/reports/event_popularity?college_id=&type=`
- GET `/reports/event_attendance/{event_id}`
- GET `/reports/event_feedback/{event_id}`
- GET `/reports/student_participation/{student_id}`
- GET `/reports/top_active_students?college_id=&limit=3`

## Workflows (Sequence – text sketch)
**Registration → Attendance → Reporting**
1. Admin creates event under a college.
2. Student registers (UNIQUE ensures no duplicate registration).
3. On event day, staff marks attendance once per student.
4. Student submits single feedback (1–5).
5. Reports use aggregates over registrations/attendance/feedback.

## Edge Cases & Handling
- Duplicate registration/attendance/feedback → rejected by UNIQUE constraints.
- Missing feedback → averages computed only over given ratings.
- Cancelled events → could add `status` in `events` (future enhancement).
- Cross-college registration → allowed only if student.college_id == event.college_id (can be enforced at app level; kept flexible in prototype).

## Scale Considerations
- ~50 colleges × 500 students × 20 events/semester ⇒ manageable for SQLite prototype.
- For production: Postgres, indexes on foreign keys and report columns, pagination on report endpoints.