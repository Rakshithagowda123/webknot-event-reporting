# Seed some sample data
import os
from app import app, db, College, Student, Event, Registration, Attendance, Feedback
from datetime import datetime, timedelta

with app.app_context():
    db.drop_all()
    db.create_all()

    c1 = College(name='REVA University', code='REVA')
    c2 = College(name='Tech Valley Institute', code='TVI')
    db.session.add_all([c1, c2])
    db.session.commit()

    students = []
    for idx, c in enumerate([c1, c2], start=1):
        for i in range(1, 6):
            s = Student(college_id=c.id, name=f'Student{i}_C{idx}', email=f'student{i}_c{idx}@example.com', year=3, branch='CSE')
            students.append(s)
    db.session.add_all(students)
    db.session.commit()

    now = datetime.utcnow()
    events = [
        Event(college_id=c1.id, title='React Workshop', type='Workshop', description='Intro to React', location='Auditorium', start_datetime=(now+timedelta(days=1)).isoformat(), end_datetime=(now+timedelta(days=1, hours=3)).isoformat()),
        Event(college_id=c1.id, title='AI Hackathon', type='Hackathon', description='24h AI build', location='Lab 1', start_datetime=(now+timedelta(days=3)).isoformat(), end_datetime=(now+timedelta(days=3, hours=24)).isoformat()),
        Event(college_id=c2.id, title='Cloud Seminar', type='Seminar', description='Cloud Trends', location='Seminar Hall', start_datetime=(now+timedelta(days=2)).isoformat(), end_datetime=(now+timedelta(days=2, hours=2)).isoformat()),
        Event(college_id=c2.id, title='Tech Fest', type='Fest', description='Annual Fest', location='Grounds', start_datetime=(now+timedelta(days=10)).isoformat(), end_datetime=(now+timedelta(days=10, hours=6)).isoformat()),
    ]
    db.session.add_all(events)
    db.session.commit()

    # Register 3 students from each college into the first event of their college
    for e in events:
        college_students = [s for s in students if s.college_id == e.college_id][:3]
        for s in college_students:
            db.session.add(Registration(student_id=s.id, event_id=e.id))
    db.session.commit()

    # Mark attendance for some students
    regs = db.session.query(Registration).all()
    for r in regs[:4]:  # mark first 4 present
        db.session.add(Attendance(student_id=r.student_id, event_id=r.event_id, present=1))
    db.session.commit()

    # Feedback for first event
    first_event = events[0]
    for r in db.session.query(Registration).filter_by(event_id=first_event.id).all():
        db.session.add(Feedback(student_id=r.student_id, event_id=first_event.id, rating=4, comment='Great session!'))
    db.session.commit()

    print('Database initialized with sample data.')